<?php
require_once __DIR__ . "/../../configuraciones/base_datos.php";
require_once __DIR__ . "/../../configuraciones/ayudas.php";

class ListaPrecio {
    public static function asegurar_tablas(): void {
        $pdo = obtener_pdo();
        if ($pdo === null)
            return;
        try {
            $pdo->exec("CREATE TABLE IF NOT EXISTS listas_precios (
                id INT AUTO_INCREMENT PRIMARY KEY,
                nombre VARCHAR(80) NOT NULL,
                activo TINYINT(1) NOT NULL DEFAULT 1,
                creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            $pdo->exec("CREATE TABLE IF NOT EXISTS producto_precios (
                id_producto INT NOT NULL,
                id_lista INT NOT NULL,
                porcentaje DECIMAL(12,4) NOT NULL DEFAULT 0,
                precio DECIMAL(14,2) NOT NULL DEFAULT 0,
                PRIMARY KEY (id_producto, id_lista)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            $st = $pdo->query("SELECT COUNT(*) AS total FROM listas_precios");
            $r = $st ? $st->fetch() : null;
            if (!$r || (int)$r["total"] === 0) {
                $pdo->prepare("INSERT INTO listas_precios (nombre, activo) VALUES (?, 1), (?, 1)")
                    ->execute(["Publico", "Mayorista"]);
            }
            self::asegurar_columna_cliente($pdo);
        } catch (Throwable $e) {
            registrar_log("ListaPrecio::asegurar_tablas", $e->getMessage());
        }
    }

    public static function listar(bool $solo_activas = false): array {
        self::asegurar_tablas();
        $lista = [];
        $pdo = obtener_pdo();
        if ($pdo !== null) {
            try {
                $sql = "SELECT id, nombre, activo, creado_en FROM listas_precios";
                if ($solo_activas)
                    $sql .= " WHERE activo = 1";
                $sql .= " ORDER BY id ASC";
                $st = $pdo->prepare($sql);
                $st->execute();
                $rows = $st->fetchAll();
                if (is_array($rows))
                    $lista = $rows;
            } catch (Throwable $e) {
                registrar_log("ListaPrecio::listar", $e->getMessage());
            }
        }
        return $lista;
    }

    public static function id_predeterminada(): int {
        $listas = self::listar(true);
        return isset($listas[0]["id"]) ? (int)$listas[0]["id"] : 1;
    }

    public static function crear(string $nombre, int $activo): bool {
        self::asegurar_tablas();
        $pdo = obtener_pdo();
        if ($pdo === null)
            return false;
        try {
            $st = $pdo->prepare("INSERT INTO listas_precios (nombre, activo) VALUES (?, ?)");
            return $st->execute([$nombre, $activo]);
        } catch (Throwable $e) {
            registrar_log("ListaPrecio::crear", $e->getMessage());
            return false;
        }
    }

    public static function actualizar(int $id, string $nombre, int $activo): bool {
        self::asegurar_tablas();
        $pdo = obtener_pdo();
        if ($pdo === null || $id <= 0)
            return false;
        try {
            $st = $pdo->prepare("UPDATE listas_precios SET nombre = ?, activo = ? WHERE id = ?");
            return $st->execute([$nombre, $activo, $id]);
        } catch (Throwable $e) {
            registrar_log("ListaPrecio::actualizar", $e->getMessage());
            return false;
        }
    }

    public static function eliminar(int $id): bool {
        self::asegurar_tablas();
        $pdo = obtener_pdo();
        if ($pdo === null || $id <= 0)
            return false;
        try {
            $st = $pdo->prepare("DELETE FROM listas_precios WHERE id = ?");
            return $st->execute([$id]);
        } catch (Throwable $e) {
            registrar_log("ListaPrecio::eliminar", $e->getMessage());
            return false;
        }
    }

    public static function precios_producto(int $id_producto): array {
        self::asegurar_tablas();
        $precios = [];
        $pdo = obtener_pdo();
        if ($pdo !== null && $id_producto > 0) {
            try {
                $st = $pdo->prepare("SELECT id_lista, porcentaje, precio FROM producto_precios WHERE id_producto = ?");
                $st->execute([$id_producto]);
                foreach ($st->fetchAll() as $row)
                    $precios[(int)$row["id_lista"]] = $row;
            } catch (Throwable $e) {
                registrar_log("ListaPrecio::precios_producto", $e->getMessage());
            }
        }
        return $precios;
    }

    public static function guardar_precio_producto(int $id_producto, int $id_lista, float $porcentaje, float $precio): bool {
        self::asegurar_tablas();
        $pdo = obtener_pdo();
        if ($pdo === null || $id_producto <= 0 || $id_lista <= 0)
            return false;
        try {
            if ($porcentaje < 0)
                $porcentaje = 0;
            if ($precio < 0)
                $precio = 0;
            $sql = "INSERT INTO producto_precios (id_producto, id_lista, porcentaje, precio)
                    VALUES (?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE porcentaje = VALUES(porcentaje), precio = VALUES(precio)";
            $st = $pdo->prepare($sql);
            return $st->execute([$id_producto, $id_lista, $porcentaje, $precio]);
        } catch (Throwable $e) {
            registrar_log("ListaPrecio::guardar_precio_producto", $e->getMessage());
            return false;
        }
    }

    public static function precio_producto(int $id_producto, int $id_lista): ?float {
        $precio = self::precio_producto_completo($id_producto, $id_lista);
        return $precio !== null ? (float)$precio["precio"] : null;
    }

    public static function precio_producto_completo(int $id_producto, int $id_lista): ?array {
        self::asegurar_tablas();
        $pdo = obtener_pdo();
        if ($pdo === null || $id_producto <= 0 || $id_lista <= 0)
            return null;
        try {
            $sql = "SELECT COALESCE(pp.porcentaje, 0) AS porcentaje,
                           CASE
                             WHEN COALESCE(pp.precio, 0) > 0 THEN pp.precio
                             WHEN COALESCE(pp.porcentaje, 0) > 0 THEN (COALESCE(s.precio_costo, 0) * p.factor_conversion) * (1 + (pp.porcentaje / 100))
                             ELSE p.precio_final
                           END AS precio
                    FROM productos p
                    LEFT JOIN stock s ON s.id = p.id_stock
                    LEFT JOIN producto_precios pp ON pp.id_producto = p.id AND pp.id_lista = ?
                    WHERE p.id = ?
                    LIMIT 1";
            $st = $pdo->prepare($sql);
            $st->execute([$id_lista, $id_producto]);
            $r = $st->fetch();
            if ($r)
                return [
                    "porcentaje" => (float)$r["porcentaje"],
                    "precio" => (float)$r["precio"]
                ];
        } catch (Throwable $e) {
            registrar_log("ListaPrecio::precio_producto_completo", $e->getMessage());
        }
        return null;
    }

    public static function productos_para_exportar(int $id_lista = 0): array {
        self::asegurar_tablas();
        $lista = [];
        $pdo = obtener_pdo();
        if ($pdo !== null) {
            try {
                $join = $id_lista > 0 ? "LEFT JOIN producto_precios pp ON pp.id_producto = p.id AND pp.id_lista = ?" : "";
                $sql = "SELECT p.id, p.nombre, p.cod_barras, p.precio_final, COALESCE(s.unidad, '') AS unidad,
                               " . ($id_lista > 0 ? "CASE
                                 WHEN COALESCE(pp.precio, 0) > 0 THEN pp.precio
                                 WHEN COALESCE(pp.porcentaje, 0) > 0 THEN (COALESCE(s.precio_costo, 0) * p.factor_conversion) * (1 + (pp.porcentaje / 100))
                                 ELSE p.precio_final
                               END" : "p.precio_final") . " AS precio_lista
                        FROM productos p
                        LEFT JOIN stock s ON s.id = p.id_stock
                        $join
                        WHERE p.activo = 1
                        ORDER BY p.nombre ASC";
                $st = $pdo->prepare($sql);
                $id_lista > 0 ? $st->execute([$id_lista]) : $st->execute();
                $rows = $st->fetchAll();
                if (is_array($rows))
                    $lista = $rows;
            } catch (Throwable $e) {
                registrar_log("ListaPrecio::productos_para_exportar", $e->getMessage());
            }
        }
        return $lista;
    }

    private static function asegurar_columna_cliente(PDO $pdo): void {
        $st = $pdo->prepare("SHOW COLUMNS FROM clientes LIKE ?");
        $st->execute(["id_lista_precio"]);
        if (!$st->fetch())
            $pdo->exec("ALTER TABLE clientes ADD COLUMN id_lista_precio INT NULL AFTER email");
    }
}
