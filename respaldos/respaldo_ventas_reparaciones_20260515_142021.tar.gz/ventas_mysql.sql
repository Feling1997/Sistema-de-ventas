-- Respaldo MySQL sistema_ventas
-- Generado: 2026-05-15 14:20:21

SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `clientes`;
CREATE TABLE `clientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(120) NOT NULL,
  `dni` varchar(20) DEFAULT NULL,
  `tipo_documento` varchar(20) NOT NULL DEFAULT 'DNI',
  `condicion_iva` varchar(40) NOT NULL DEFAULT 'Consumidor Final',
  `email` varchar(120) DEFAULT NULL,
  `id_lista_precio` int(11) DEFAULT NULL,
  `telefono` varchar(30) DEFAULT NULL,
  `direccion` varchar(200) DEFAULT NULL,
  `creado_en` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cliente_dni` (`dni`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `clientes` (`id`,`nombre`,`dni`,`tipo_documento`,`condicion_iva`,`email`,`id_lista_precio`,`telefono`,`direccion`,`creado_en`) VALUES ('1','Consumidor Final',NULL,'DNI','Consumidor Final',NULL,NULL,NULL,NULL,'2026-01-06 17:21:25');
INSERT INTO `clientes` (`id`,`nombre`,`dni`,`tipo_documento`,`condicion_iva`,`email`,`id_lista_precio`,`telefono`,`direccion`,`creado_en`) VALUES ('2','Daniel Espindola','20123563','DNI','Consumidor Final',NULL,NULL,'3743564785','San Martin 1520','2026-01-27 16:40:08');
INSERT INTO `clientes` (`id`,`nombre`,`dni`,`tipo_documento`,`condicion_iva`,`email`,`id_lista_precio`,`telefono`,`direccion`,`creado_en`) VALUES ('3','Franco Feling','40337270','DNI','Consumidor Final',NULL,NULL,'3743425123',NULL,'2026-02-24 16:47:06');

DROP TABLE IF EXISTS `cuentas_corrientes`;
CREATE TABLE `cuentas_corrientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_cliente` int(11) NOT NULL,
  `id_venta` int(11) DEFAULT NULL,
  `concepto` varchar(180) NOT NULL,
  `total` decimal(14,2) NOT NULL DEFAULT 0.00,
  `saldo` decimal(14,2) NOT NULL DEFAULT 0.00,
  `estado` varchar(20) NOT NULL DEFAULT 'ABIERTA',
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_cc_cliente` (`id_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `cuentas_corrientes_cuotas`;
CREATE TABLE `cuentas_corrientes_cuotas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_cuenta` int(11) NOT NULL,
  `numero` int(11) NOT NULL,
  `vencimiento` date NOT NULL,
  `monto` decimal(14,2) NOT NULL DEFAULT 0.00,
  `pagado` decimal(14,2) NOT NULL DEFAULT 0.00,
  `estado` varchar(20) NOT NULL DEFAULT 'PENDIENTE',
  `pagado_en` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_cc_cuota_vto` (`vencimiento`),
  KEY `idx_cc_cuota_cuenta` (`id_cuenta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `cuentas_corrientes_recibos`;
CREATE TABLE `cuentas_corrientes_recibos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_cuenta` int(11) NOT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp(),
  `monto` decimal(14,2) NOT NULL DEFAULT 0.00,
  `forma_pago` varchar(40) NOT NULL DEFAULT 'contado',
  `observacion` varchar(220) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_cc_recibo_cuenta` (`id_cuenta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `detalle_presupuesto`;
CREATE TABLE `detalle_presupuesto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_presupuesto` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `producto_nombre` varchar(150) NOT NULL,
  `cantidad` decimal(10,3) NOT NULL,
  `precio_unit` decimal(10,2) NOT NULL,
  `descuento` decimal(10,2) NOT NULL DEFAULT 0.00,
  `subtotal` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_detalle_presupuesto` (`id_presupuesto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `detalle_venta`;
CREATE TABLE `detalle_venta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_venta` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `cantidad` decimal(12,3) NOT NULL,
  `precio_unit` decimal(12,2) NOT NULL,
  `descuento` decimal(12,2) NOT NULL DEFAULT 0.00,
  `subtotal` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_detalle_venta` (`id_venta`),
  KEY `fk_detalle_producto` (`id_producto`),
  CONSTRAINT `fk_detalle_producto` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_detalle_venta` FOREIGN KEY (`id_venta`) REFERENCES `ventas` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `detalle_venta` (`id`,`id_venta`,`id_producto`,`cantidad`,`precio_unit`,`descuento`,`subtotal`) VALUES ('1','1','1','5.000','1600.00','0.00','8000.00');
INSERT INTO `detalle_venta` (`id`,`id_venta`,`id_producto`,`cantidad`,`precio_unit`,`descuento`,`subtotal`) VALUES ('2','2','1','10.000','1600.00','10.00','15990.00');
INSERT INTO `detalle_venta` (`id`,`id_venta`,`id_producto`,`cantidad`,`precio_unit`,`descuento`,`subtotal`) VALUES ('3','3','1','10.000','1600.00','0.00','16000.00');
INSERT INTO `detalle_venta` (`id`,`id_venta`,`id_producto`,`cantidad`,`precio_unit`,`descuento`,`subtotal`) VALUES ('4','4','2','2.000','3000.00','50.00','5950.00');
INSERT INTO `detalle_venta` (`id`,`id_venta`,`id_producto`,`cantidad`,`precio_unit`,`descuento`,`subtotal`) VALUES ('5','5','2','1.000','3000.00','10.00','2700.00');
INSERT INTO `detalle_venta` (`id`,`id_venta`,`id_producto`,`cantidad`,`precio_unit`,`descuento`,`subtotal`) VALUES ('6','6','1','100.000','1600.00','5.00','152000.00');
INSERT INTO `detalle_venta` (`id`,`id_venta`,`id_producto`,`cantidad`,`precio_unit`,`descuento`,`subtotal`) VALUES ('7','7','2','10.000','3000.00','5.00','28500.00');
INSERT INTO `detalle_venta` (`id`,`id_venta`,`id_producto`,`cantidad`,`precio_unit`,`descuento`,`subtotal`) VALUES ('8','8','1','1.000','1600.00','0.00','1600.00');
INSERT INTO `detalle_venta` (`id`,`id_venta`,`id_producto`,`cantidad`,`precio_unit`,`descuento`,`subtotal`) VALUES ('9','8','2','1.000','3000.00','0.00','3000.00');
INSERT INTO `detalle_venta` (`id`,`id_venta`,`id_producto`,`cantidad`,`precio_unit`,`descuento`,`subtotal`) VALUES ('10','9','2','2.000','3000.00','20.00','4800.00');
INSERT INTO `detalle_venta` (`id`,`id_venta`,`id_producto`,`cantidad`,`precio_unit`,`descuento`,`subtotal`) VALUES ('11','10','3','1.000','7000.00','0.00','7000.00');
INSERT INTO `detalle_venta` (`id`,`id_venta`,`id_producto`,`cantidad`,`precio_unit`,`descuento`,`subtotal`) VALUES ('12','11','1','1.000','24000.00','0.00','24000.00');
INSERT INTO `detalle_venta` (`id`,`id_venta`,`id_producto`,`cantidad`,`precio_unit`,`descuento`,`subtotal`) VALUES ('13','11','6','1.000','1050000.00','0.00','1050000.00');
INSERT INTO `detalle_venta` (`id`,`id_venta`,`id_producto`,`cantidad`,`precio_unit`,`descuento`,`subtotal`) VALUES ('14','12','6','6.000','1050000.00','0.00','6300000.00');
INSERT INTO `detalle_venta` (`id`,`id_venta`,`id_producto`,`cantidad`,`precio_unit`,`descuento`,`subtotal`) VALUES ('15','13','1','1.000','24000.00','0.00','24000.00');
INSERT INTO `detalle_venta` (`id`,`id_venta`,`id_producto`,`cantidad`,`precio_unit`,`descuento`,`subtotal`) VALUES ('16','14','2','1.000','3000.00','0.00','3000.00');
INSERT INTO `detalle_venta` (`id`,`id_venta`,`id_producto`,`cantidad`,`precio_unit`,`descuento`,`subtotal`) VALUES ('17','15','2','1.000','3000.00','0.00','3000.00');
INSERT INTO `detalle_venta` (`id`,`id_venta`,`id_producto`,`cantidad`,`precio_unit`,`descuento`,`subtotal`) VALUES ('18','16','1','1.000','24000.00','0.00','24000.00');
INSERT INTO `detalle_venta` (`id`,`id_venta`,`id_producto`,`cantidad`,`precio_unit`,`descuento`,`subtotal`) VALUES ('19','17','2','1.000','3000.00','0.00','3000.00');
INSERT INTO `detalle_venta` (`id`,`id_venta`,`id_producto`,`cantidad`,`precio_unit`,`descuento`,`subtotal`) VALUES ('20','18','1','1.000','24000.00','0.00','24000.00');
INSERT INTO `detalle_venta` (`id`,`id_venta`,`id_producto`,`cantidad`,`precio_unit`,`descuento`,`subtotal`) VALUES ('21','19','1','1.000','24000.00','0.00','24000.00');
INSERT INTO `detalle_venta` (`id`,`id_venta`,`id_producto`,`cantidad`,`precio_unit`,`descuento`,`subtotal`) VALUES ('22','20','3','1.000','105000.00','0.00','105000.00');
INSERT INTO `detalle_venta` (`id`,`id_venta`,`id_producto`,`cantidad`,`precio_unit`,`descuento`,`subtotal`) VALUES ('23','21','1','1.000','24000.00','0.00','24000.00');
INSERT INTO `detalle_venta` (`id`,`id_venta`,`id_producto`,`cantidad`,`precio_unit`,`descuento`,`subtotal`) VALUES ('24','21','2','1.000','22500.00','0.00','22500.00');
INSERT INTO `detalle_venta` (`id`,`id_venta`,`id_producto`,`cantidad`,`precio_unit`,`descuento`,`subtotal`) VALUES ('25','22','2','1.000','22500.00','0.00','22500.00');

DROP TABLE IF EXISTS `fiscal_cola`;
CREATE TABLE `fiscal_cola` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_comprobante` int(11) NOT NULL,
  `estado` enum('PENDIENTE','EN_PROCESO','FINALIZADO','ERROR') NOT NULL DEFAULT 'PENDIENTE',
  `intentos` int(11) NOT NULL DEFAULT 0,
  `ultimo_error` text DEFAULT NULL,
  `proximo_intento` datetime DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_fiscal_cola_estado` (`estado`,`proximo_intento`),
  KEY `fk_fiscal_cola_comprobante` (`id_comprobante`),
  CONSTRAINT `fk_fiscal_cola_comprobante` FOREIGN KEY (`id_comprobante`) REFERENCES `fiscal_comprobantes` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `fiscal_cola` (`id`,`id_comprobante`,`estado`,`intentos`,`ultimo_error`,`proximo_intento`,`creado_en`,`actualizado_en`) VALUES ('1','1','PENDIENTE','0',NULL,NULL,'2026-04-30 09:23:56','2026-04-30 09:23:56');
INSERT INTO `fiscal_cola` (`id`,`id_comprobante`,`estado`,`intentos`,`ultimo_error`,`proximo_intento`,`creado_en`,`actualizado_en`) VALUES ('2','2','PENDIENTE','0',NULL,NULL,'2026-04-30 09:46:33','2026-04-30 09:46:33');
INSERT INTO `fiscal_cola` (`id`,`id_comprobante`,`estado`,`intentos`,`ultimo_error`,`proximo_intento`,`creado_en`,`actualizado_en`) VALUES ('3','3','PENDIENTE','0',NULL,NULL,'2026-04-30 09:52:20','2026-04-30 09:52:20');
INSERT INTO `fiscal_cola` (`id`,`id_comprobante`,`estado`,`intentos`,`ultimo_error`,`proximo_intento`,`creado_en`,`actualizado_en`) VALUES ('4','4','PENDIENTE','0',NULL,NULL,'2026-04-30 11:38:50','2026-04-30 11:38:50');
INSERT INTO `fiscal_cola` (`id`,`id_comprobante`,`estado`,`intentos`,`ultimo_error`,`proximo_intento`,`creado_en`,`actualizado_en`) VALUES ('5','5','PENDIENTE','0',NULL,NULL,'2026-04-30 11:47:46','2026-04-30 11:47:46');
INSERT INTO `fiscal_cola` (`id`,`id_comprobante`,`estado`,`intentos`,`ultimo_error`,`proximo_intento`,`creado_en`,`actualizado_en`) VALUES ('6','6','PENDIENTE','0',NULL,NULL,'2026-04-30 11:52:05','2026-04-30 11:52:05');

DROP TABLE IF EXISTS `fiscal_comprobantes`;
CREATE TABLE `fiscal_comprobantes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_venta` int(11) NOT NULL,
  `tipo_operacion` enum('factura','presupuesto') NOT NULL DEFAULT 'factura',
  `estado` enum('PENDIENTE','EN_PROCESO','APROBADO','RECHAZADO','ERROR') NOT NULL DEFAULT 'PENDIENTE',
  `proveedor` varchar(30) NOT NULL DEFAULT 'api_rest',
  `punto_venta` int(11) DEFAULT NULL,
  `tipo_comprobante` int(11) DEFAULT NULL,
  `numero_comprobante` bigint(20) DEFAULT NULL,
  `cae` varchar(30) DEFAULT NULL,
  `cae_vencimiento` date DEFAULT NULL,
  `payload_json` longtext NOT NULL,
  `respuesta_json` longtext DEFAULT NULL,
  `ultimo_error` text DEFAULT NULL,
  `intentos` int(11) NOT NULL DEFAULT 0,
  `proximo_intento` datetime DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_fiscal_comprobantes_venta` (`id_venta`),
  KEY `idx_fiscal_estado` (`estado`),
  CONSTRAINT `fk_fiscal_comprobantes_venta` FOREIGN KEY (`id_venta`) REFERENCES `ventas` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `fiscal_comprobantes` (`id`,`id_venta`,`tipo_operacion`,`estado`,`proveedor`,`punto_venta`,`tipo_comprobante`,`numero_comprobante`,`cae`,`cae_vencimiento`,`payload_json`,`respuesta_json`,`ultimo_error`,`intentos`,`proximo_intento`,`creado_en`,`actualizado_en`) VALUES ('1','13','factura','PENDIENTE','api_rest','1','6',NULL,NULL,NULL,'{\"tipo_operacion\":\"factura\",\"venta\":{\"id\":13,\"fecha\":\"2026-04-30 09:23:56\",\"total\":24000},\"emisor\":{\"cuit\":\"\",\"punto_venta\":1,\"condicion_iva\":\"\",\"razon_social\":\"\",\"inicio_actividades\":\"\"},\"comprobante\":{\"tipo\":6,\"concepto\":1,\"moneda\":\"PES\",\"cotizacion\":1},\"receptor\":{\"nombre\":\"Consumidor Final\",\"documento\":\"\",\"tipo_documento\":\"DNI\",\"condicion_iva\":\"Consumidor Final\",\"email\":\"\"},\"items\":[{\"producto\":\"Harina Integral x 1 Kg\",\"cantidad\":1,\"precio_unitario\":24000,\"descuento\":0,\"subtotal\":24000}]}',NULL,NULL,'0',NULL,'2026-04-30 09:23:56','2026-04-30 09:23:56');
INSERT INTO `fiscal_comprobantes` (`id`,`id_venta`,`tipo_operacion`,`estado`,`proveedor`,`punto_venta`,`tipo_comprobante`,`numero_comprobante`,`cae`,`cae_vencimiento`,`payload_json`,`respuesta_json`,`ultimo_error`,`intentos`,`proximo_intento`,`creado_en`,`actualizado_en`) VALUES ('2','14','factura','PENDIENTE','api_rest','1','6',NULL,NULL,NULL,'{\"tipo_operacion\":\"factura\",\"venta\":{\"id\":14,\"fecha\":\"2026-04-30 09:46:33\",\"total\":3000},\"emisor\":{\"cuit\":\"\",\"punto_venta\":1,\"condicion_iva\":\"\",\"razon_social\":\"\",\"domicilio\":\"\",\"ingresos_brutos\":\"\",\"inicio_actividades\":\"\"},\"comprobante\":{\"tipo\":6,\"concepto\":1,\"moneda\":\"PES\",\"cotizacion\":1,\"iva_porcentaje\":21},\"receptor\":{\"nombre\":\"Consumidor Final\",\"documento\":\"\",\"tipo_documento\":\"DNI\",\"condicion_iva\":\"Consumidor Final\",\"email\":\"\"},\"items\":[{\"producto\":\"Almendras x 100 Gr\",\"cantidad\":1,\"precio_unitario\":3000,\"descuento\":0,\"subtotal\":3000}]}',NULL,NULL,'0',NULL,'2026-04-30 09:46:33','2026-04-30 09:46:33');
INSERT INTO `fiscal_comprobantes` (`id`,`id_venta`,`tipo_operacion`,`estado`,`proveedor`,`punto_venta`,`tipo_comprobante`,`numero_comprobante`,`cae`,`cae_vencimiento`,`payload_json`,`respuesta_json`,`ultimo_error`,`intentos`,`proximo_intento`,`creado_en`,`actualizado_en`) VALUES ('3','15','factura','PENDIENTE','api_rest','1','6',NULL,NULL,NULL,'{\"tipo_operacion\":\"factura\",\"venta\":{\"id\":15,\"fecha\":\"2026-04-30 09:52:20\",\"total\":3000},\"emisor\":{\"cuit\":\"\",\"punto_venta\":1,\"condicion_iva\":\"\",\"razon_social\":\"\",\"domicilio\":\"\",\"ingresos_brutos\":\"\",\"inicio_actividades\":\"\"},\"comprobante\":{\"tipo\":6,\"concepto\":1,\"moneda\":\"PES\",\"cotizacion\":1,\"iva_porcentaje\":21,\"copia\":\"ORIGINAL\",\"remito\":\"\"},\"receptor\":{\"nombre\":\"Consumidor Final\",\"documento\":\"\",\"tipo_documento\":\"DNI\",\"condicion_iva\":\"Consumidor Final\",\"email\":\"\"},\"items\":[{\"producto\":\"Almendras x 100 Gr\",\"cantidad\":1,\"precio_unitario\":3000,\"descuento\":0,\"subtotal\":3000}]}',NULL,NULL,'0',NULL,'2026-04-30 09:52:20','2026-04-30 09:52:20');
INSERT INTO `fiscal_comprobantes` (`id`,`id_venta`,`tipo_operacion`,`estado`,`proveedor`,`punto_venta`,`tipo_comprobante`,`numero_comprobante`,`cae`,`cae_vencimiento`,`payload_json`,`respuesta_json`,`ultimo_error`,`intentos`,`proximo_intento`,`creado_en`,`actualizado_en`) VALUES ('4','16','factura','PENDIENTE','api_rest','1','6',NULL,NULL,NULL,'{\"tipo_operacion\":\"factura\",\"venta\":{\"id\":16,\"fecha\":\"2026-04-30 11:38:50\",\"total\":24000},\"emisor\":{\"cuit\":\"20-11950408-3\",\"punto_venta\":1,\"condicion_iva\":\"Responsable Inscripto\",\"razon_social\":\"FELING CARLOS RODOLFO\",\"domicilio\":\"Lopez y Planes 2480, Puerto Rico, Misiones\",\"ingresos_brutos\":\"Ingresos Brutos\",\"inicio_actividades\":\"2026-04-27\",\"telefonos\":\"\",\"whatsapp\":\"3743559120\",\"email\":\"felingfranco@gmail.com\",\"sitio_web\":\"@agroapimad\",\"texto_pie_ticket\":\"Gracias por su compra\"},\"comprobante\":{\"tipo\":6,\"concepto\":1,\"moneda\":\"PES\",\"cotizacion\":1,\"iva_porcentaje\":21,\"copia\":\"ORIGINAL\",\"remito\":\"\"},\"receptor\":{\"nombre\":\"Consumidor Final\",\"documento\":\"\",\"tipo_documento\":\"DNI\",\"condicion_iva\":\"Consumidor Final\",\"email\":\"\"},\"items\":[{\"producto\":\"Harina Integral x 1 Kg\",\"cantidad\":1,\"precio_unitario\":24000,\"descuento\":0,\"subtotal\":24000}]}',NULL,NULL,'0',NULL,'2026-04-30 11:38:50','2026-04-30 11:38:50');
INSERT INTO `fiscal_comprobantes` (`id`,`id_venta`,`tipo_operacion`,`estado`,`proveedor`,`punto_venta`,`tipo_comprobante`,`numero_comprobante`,`cae`,`cae_vencimiento`,`payload_json`,`respuesta_json`,`ultimo_error`,`intentos`,`proximo_intento`,`creado_en`,`actualizado_en`) VALUES ('5','17','factura','PENDIENTE','api_rest','1','6',NULL,NULL,NULL,'{\"tipo_operacion\":\"factura\",\"venta\":{\"id\":17,\"fecha\":\"2026-04-30 11:47:46\",\"total\":3000},\"emisor\":{\"cuit\":\"20-11950408-3\",\"punto_venta\":1,\"condicion_iva\":\"Responsable Inscripto\",\"razon_social\":\"FELING CARLOS RODOLFO\",\"domicilio\":\"Lopez y Planes 2480, Puerto Rico, Misiones\",\"ingresos_brutos\":\"Ingresos Brutos\",\"inicio_actividades\":\"2026-04-27\",\"telefonos\":\"\",\"whatsapp\":\"3743559120\",\"email\":\"felingfranco@gmail.com\",\"sitio_web\":\"@agroapimad\",\"texto_pie_ticket\":\"Gracias por su compra\"},\"comprobante\":{\"tipo\":6,\"concepto\":1,\"moneda\":\"PES\",\"cotizacion\":1,\"iva_porcentaje\":21,\"copia\":\"ORIGINAL\",\"remito\":\"\"},\"receptor\":{\"nombre\":\"Consumidor Final\",\"documento\":\"\",\"tipo_documento\":\"DNI\",\"condicion_iva\":\"Consumidor Final\",\"email\":\"\"},\"items\":[{\"producto\":\"Almendras x 100 Gr\",\"cantidad\":1,\"precio_unitario\":3000,\"descuento\":0,\"subtotal\":3000}]}',NULL,NULL,'0',NULL,'2026-04-30 11:47:46','2026-04-30 11:47:46');
INSERT INTO `fiscal_comprobantes` (`id`,`id_venta`,`tipo_operacion`,`estado`,`proveedor`,`punto_venta`,`tipo_comprobante`,`numero_comprobante`,`cae`,`cae_vencimiento`,`payload_json`,`respuesta_json`,`ultimo_error`,`intentos`,`proximo_intento`,`creado_en`,`actualizado_en`) VALUES ('6','18','factura','PENDIENTE','api_rest','1','6',NULL,NULL,NULL,'{\"tipo_operacion\":\"factura\",\"venta\":{\"id\":18,\"fecha\":\"2026-04-30 11:52:05\",\"total\":24000},\"emisor\":{\"cuit\":\"20-11950408-3\",\"punto_venta\":1,\"condicion_iva\":\"Responsable Inscripto\",\"razon_social\":\"FELING CARLOS RODOLFO\",\"domicilio\":\"Lopez y Planes 2480, Puerto Rico, Misiones\",\"ingresos_brutos\":\"Ingresos Brutos\",\"inicio_actividades\":\"2026-04-27\",\"telefonos\":\"\",\"whatsapp\":\"3743559120\",\"email\":\"felingfranco@gmail.com\",\"sitio_web\":\"@agroapimad\",\"texto_pie_ticket\":\"Gracias por su compra\"},\"comprobante\":{\"tipo\":6,\"concepto\":1,\"moneda\":\"PES\",\"cotizacion\":1,\"iva_porcentaje\":21,\"copia\":\"ORIGINAL\",\"remito\":\"\"},\"receptor\":{\"nombre\":\"Consumidor Final\",\"documento\":\"\",\"tipo_documento\":\"DNI\",\"condicion_iva\":\"Consumidor Final\",\"email\":\"\"},\"items\":[{\"producto\":\"Harina Integral x 1 Kg\",\"cantidad\":1,\"precio_unitario\":24000,\"descuento\":0,\"subtotal\":24000}]}',NULL,NULL,'0',NULL,'2026-04-30 11:52:05','2026-04-30 11:52:05');

DROP TABLE IF EXISTS `listas_precios`;
CREATE TABLE `listas_precios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(80) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `listas_precios` (`id`,`nombre`,`activo`,`creado_en`) VALUES ('2','Mayorista Depósito','1','2026-05-11 10:28:26');
INSERT INTO `listas_precios` (`id`,`nombre`,`activo`,`creado_en`) VALUES ('3','Mayorista Domicilio','1','2026-05-11 10:40:58');
INSERT INTO `listas_precios` (`id`,`nombre`,`activo`,`creado_en`) VALUES ('4','Costo','1','2026-05-11 10:41:29');
INSERT INTO `listas_precios` (`id`,`nombre`,`activo`,`creado_en`) VALUES ('6','Reventa','1','2026-05-11 11:05:33');
INSERT INTO `listas_precios` (`id`,`nombre`,`activo`,`creado_en`) VALUES ('7','Preferencial','1','2026-05-11 11:05:46');
INSERT INTO `listas_precios` (`id`,`nombre`,`activo`,`creado_en`) VALUES ('8','Empresas','1','2026-05-11 11:05:55');

DROP TABLE IF EXISTS `presupuestos`;
CREATE TABLE `presupuestos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` datetime NOT NULL DEFAULT current_timestamp(),
  `id_cliente` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `estado` varchar(20) NOT NULL DEFAULT 'ABIERTO',
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_presupuestos_cliente` (`id_cliente`),
  KEY `idx_presupuestos_fecha` (`fecha`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `producto_precios`;
CREATE TABLE `producto_precios` (
  `id_producto` int(11) NOT NULL,
  `id_lista` int(11) NOT NULL,
  `porcentaje` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `precio` decimal(14,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id_producto`,`id_lista`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `producto_precios` (`id_producto`,`id_lista`,`porcentaje`,`precio`) VALUES ('2','1','60.0000','24000.00');
INSERT INTO `producto_precios` (`id_producto`,`id_lista`,`porcentaje`,`precio`) VALUES ('2','2','50.0000','22500.00');
INSERT INTO `producto_precios` (`id_producto`,`id_lista`,`porcentaje`,`precio`) VALUES ('2','3','40.0000','21000.00');
INSERT INTO `producto_precios` (`id_producto`,`id_lista`,`porcentaje`,`precio`) VALUES ('2','4','0.0000','15000.00');
INSERT INTO `producto_precios` (`id_producto`,`id_lista`,`porcentaje`,`precio`) VALUES ('2','6','30.0000','19500.00');
INSERT INTO `producto_precios` (`id_producto`,`id_lista`,`porcentaje`,`precio`) VALUES ('2','7','20.0000','18000.00');
INSERT INTO `producto_precios` (`id_producto`,`id_lista`,`porcentaje`,`precio`) VALUES ('2','8','10.0000','16500.00');

DROP TABLE IF EXISTS `productos`;
CREATE TABLE `productos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(120) NOT NULL,
  `cod_barras` varchar(80) NOT NULL,
  `id_stock` int(11) NOT NULL,
  `id_asociado` int(11) DEFAULT NULL,
  `factor_conversion` decimal(12,4) NOT NULL DEFAULT 1.0000,
  `ganancia` decimal(12,2) NOT NULL DEFAULT 0.00,
  `precio_final` decimal(12,2) NOT NULL DEFAULT 0.00,
  `activo` tinyint(4) NOT NULL DEFAULT 1,
  `creado_en` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cod_barras` (`cod_barras`),
  KEY `fk_producto_stock` (`id_stock`),
  KEY `fk_producto_asociado` (`id_asociado`),
  CONSTRAINT `fk_producto_asociado` FOREIGN KEY (`id_asociado`) REFERENCES `stock` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_producto_stock` FOREIGN KEY (`id_stock`) REFERENCES `stock` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_productos_stock` FOREIGN KEY (`id_stock`) REFERENCES `stock` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `productos` (`id`,`nombre`,`cod_barras`,`id_stock`,`id_asociado`,`factor_conversion`,`ganancia`,`precio_final`,`activo`,`creado_en`) VALUES ('1','Harina Integral x 1 Kg','1','1','1','1.0000','60.00','24000.00','1','2026-01-28 17:06:00');
INSERT INTO `productos` (`id`,`nombre`,`cod_barras`,`id_stock`,`id_asociado`,`factor_conversion`,`ganancia`,`precio_final`,`activo`,`creado_en`) VALUES ('2','Almendras x 100 Gr','2','2',NULL,'1.0000','100.00','30000.00','1','2026-02-04 19:17:52');
INSERT INTO `productos` (`id`,`nombre`,`cod_barras`,`id_stock`,`id_asociado`,`factor_conversion`,`ganancia`,`precio_final`,`activo`,`creado_en`) VALUES ('3','Harina Integral x 5 Kg','3','1',NULL,'5.0000','40.00','105000.00','1','2026-02-12 17:02:00');
INSERT INTO `productos` (`id`,`nombre`,`cod_barras`,`id_stock`,`id_asociado`,`factor_conversion`,`ganancia`,`precio_final`,`activo`,`creado_en`) VALUES ('4','Harina Integral x 30 Kg','4','1',NULL,'30.0000','30.00','585000.00','1','2026-02-12 17:25:38');
INSERT INTO `productos` (`id`,`nombre`,`cod_barras`,`id_stock`,`id_asociado`,`factor_conversion`,`ganancia`,`precio_final`,`activo`,`creado_en`) VALUES ('6','Harina integral x 50 Kg','6','1',NULL,'50.0000','40.00','1050000.00','0','2026-04-28 09:10:42');

DROP TABLE IF EXISTS `reparaciones`;
CREATE TABLE `reparaciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(20) NOT NULL,
  `cliente_nombre` varchar(150) NOT NULL,
  `cliente_telefono` varchar(30) DEFAULT '',
  `marca` varchar(50) DEFAULT '',
  `modelo` varchar(50) DEFAULT '',
  `imei` varchar(30) DEFAULT '',
  `falla` text DEFAULT NULL,
  `diagnostico` text DEFAULT NULL,
  `garantia` varchar(100) DEFAULT '',
  `estado` enum('PENDIENTE','EN_REPARACION','ESP_REPUESTOS','REPARADO','ENTREGADO','CANCELADO') DEFAULT 'PENDIENTE',
  `precio` decimal(10,2) DEFAULT 0.00,
  `fecha_ingreso` date NOT NULL,
  `fecha_entrega` date DEFAULT NULL,
  `observaciones` text DEFAULT NULL,
  `id_usuario` int(11) DEFAULT 0,
  `activo` tinyint(1) DEFAULT 1,
  `creado_en` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo` (`codigo`),
  KEY `idx_estado` (`estado`),
  KEY `idx_codigo` (`codigo`),
  KEY `idx_fecha_ingreso` (`fecha_ingreso`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `reparaciones` (`id`,`codigo`,`cliente_nombre`,`cliente_telefono`,`marca`,`modelo`,`imei`,`falla`,`diagnostico`,`garantia`,`estado`,`precio`,`fecha_ingreso`,`fecha_entrega`,`observaciones`,`id_usuario`,`activo`,`creado_en`) VALUES ('1','REP-20260427-3285','Franco','3743556655','Samsung','A 54','1','Pantalla','Cambio de módulo','','ESP_REPUESTOS','60000.00','2026-04-27','2026-04-30','Falta repuesto','1','1','2026-04-27 11:42:37');
INSERT INTO `reparaciones` (`id`,`codigo`,`cliente_nombre`,`cliente_telefono`,`marca`,`modelo`,`imei`,`falla`,`diagnostico`,`garantia`,`estado`,`precio`,`fecha_ingreso`,`fecha_entrega`,`observaciones`,`id_usuario`,`activo`,`creado_en`) VALUES ('2','REP-20260427-0255','Dani','374565952','Xiami','Poco','2','No carga','Placa de carga','7 dias','ENTREGADO','45000.00','2026-04-27','2026-04-27','','1','1','2026-04-27 11:53:32');

DROP TABLE IF EXISTS `stock`;
CREATE TABLE `stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(120) NOT NULL,
  `unidad` varchar(20) NOT NULL DEFAULT 'u',
  `cantidad` decimal(12,3) NOT NULL DEFAULT 0.000,
  `stock_minimo` decimal(14,3) NOT NULL DEFAULT 0.000,
  `stock_maximo` decimal(14,3) NOT NULL DEFAULT 0.000,
  `precio_costo` decimal(12,2) NOT NULL DEFAULT 0.00,
  `activo` tinyint(4) NOT NULL DEFAULT 1,
  `creado_en` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `stock` (`id`,`nombre`,`unidad`,`cantidad`,`stock_minimo`,`stock_maximo`,`precio_costo`,`activo`,`creado_en`) VALUES ('1','Harina Integral','Kg','19.000','50.000','500.000','15000.00','1','2026-01-27 17:03:21');
INSERT INTO `stock` (`id`,`nombre`,`unidad`,`cantidad`,`stock_minimo`,`stock_maximo`,`precio_costo`,`activo`,`creado_en`) VALUES ('2','Almendras x 100 Gr','Kg','196.100','0.000','0.000','15000.00','1','2026-02-04 18:49:04');
INSERT INTO `stock` (`id`,`nombre`,`unidad`,`cantidad`,`stock_minimo`,`stock_maximo`,`precio_costo`,`activo`,`creado_en`) VALUES ('3','Azucar Mascabo','Kg','1000.000','0.000','0.000','1700.00','1','2026-05-11 11:04:09');
INSERT INTO `stock` (`id`,`nombre`,`unidad`,`cantidad`,`stock_minimo`,`stock_maximo`,`precio_costo`,`activo`,`creado_en`) VALUES ('4','Poroto Negro','Kg','50.000','50.000','500.000','1230.00','1','2026-05-11 11:04:35');

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) NOT NULL,
  `clave` varchar(255) NOT NULL,
  `rol` enum('ADMIN','VENDEDOR') NOT NULL DEFAULT 'VENDEDOR',
  `activo` tinyint(4) NOT NULL DEFAULT 1,
  `creado_en` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_usuario` (`usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `usuarios` (`id`,`usuario`,`clave`,`rol`,`activo`,`creado_en`) VALUES ('1','admin','$2y$10$CnA5SxVA4BpS8Wyutp42qOw0i8/7yugbG.3Baoxc2fWT/P888Ywju','ADMIN','1','2026-01-14 17:49:16');
INSERT INTO `usuarios` (`id`,`usuario`,`clave`,`rol`,`activo`,`creado_en`) VALUES ('3','vendedor','$2y$10$YwyVx01w7Oe5.R3tk9UcYOZxmJ/rvEZ5uJatSlBmxv89fyfIqJO/i','VENDEDOR','1','2026-02-05 17:45:58');
INSERT INTO `usuarios` (`id`,`usuario`,`clave`,`rol`,`activo`,`creado_en`) VALUES ('4','vendedor2','$2y$10$l5KRV6MrnYnAq5ynSLcTX.d5f4MRqsFUtMtzhJ/qX5H.bTcP2haby','VENDEDOR','0','2026-02-24 16:56:14');

DROP TABLE IF EXISTS `ventas`;
CREATE TABLE `ventas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` datetime NOT NULL DEFAULT current_timestamp(),
  `id_cliente` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `total` decimal(12,2) NOT NULL DEFAULT 0.00,
  `creado_en` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_venta_cliente` (`id_cliente`),
  KEY `fk_venta_usuario` (`id_usuario`),
  CONSTRAINT `fk_venta_cliente` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_venta_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `ventas` (`id`,`fecha`,`id_cliente`,`id_usuario`,`total`,`creado_en`) VALUES ('1','2026-01-28 19:04:55','2','1','8000.00','2026-01-28 19:04:55');
INSERT INTO `ventas` (`id`,`fecha`,`id_cliente`,`id_usuario`,`total`,`creado_en`) VALUES ('2','2026-01-28 19:07:55','1','1','15990.00','2026-01-28 19:07:55');
INSERT INTO `ventas` (`id`,`fecha`,`id_cliente`,`id_usuario`,`total`,`creado_en`) VALUES ('3','2026-02-02 18:09:15','1','1','16000.00','2026-02-02 18:09:15');
INSERT INTO `ventas` (`id`,`fecha`,`id_cliente`,`id_usuario`,`total`,`creado_en`) VALUES ('4','2026-02-05 18:25:40','1','3','5950.00','2026-02-05 18:25:40');
INSERT INTO `ventas` (`id`,`fecha`,`id_cliente`,`id_usuario`,`total`,`creado_en`) VALUES ('5','2026-02-05 18:51:57','2','3','2700.00','2026-02-05 18:51:57');
INSERT INTO `ventas` (`id`,`fecha`,`id_cliente`,`id_usuario`,`total`,`creado_en`) VALUES ('6','2026-02-05 19:09:07','1','3','152000.00','2026-02-05 19:09:07');
INSERT INTO `ventas` (`id`,`fecha`,`id_cliente`,`id_usuario`,`total`,`creado_en`) VALUES ('7','2026-02-09 19:21:33','1','3','28500.00','2026-02-09 19:21:33');
INSERT INTO `ventas` (`id`,`fecha`,`id_cliente`,`id_usuario`,`total`,`creado_en`) VALUES ('8','2026-02-11 17:02:51','2','1','4600.00','2026-02-11 17:02:51');
INSERT INTO `ventas` (`id`,`fecha`,`id_cliente`,`id_usuario`,`total`,`creado_en`) VALUES ('9','2026-02-24 16:45:13','2','1','4800.00','2026-02-24 16:45:13');
INSERT INTO `ventas` (`id`,`fecha`,`id_cliente`,`id_usuario`,`total`,`creado_en`) VALUES ('10','2026-02-24 16:53:15','1','1','7000.00','2026-02-24 16:53:15');
INSERT INTO `ventas` (`id`,`fecha`,`id_cliente`,`id_usuario`,`total`,`creado_en`) VALUES ('11','2026-04-28 10:57:10','3','1','1074000.00','2026-04-28 10:57:10');
INSERT INTO `ventas` (`id`,`fecha`,`id_cliente`,`id_usuario`,`total`,`creado_en`) VALUES ('12','2026-04-28 11:03:05','1','1','6300000.00','2026-04-28 11:03:05');
INSERT INTO `ventas` (`id`,`fecha`,`id_cliente`,`id_usuario`,`total`,`creado_en`) VALUES ('13','2026-04-30 09:23:56','1','1','24000.00','2026-04-30 09:23:56');
INSERT INTO `ventas` (`id`,`fecha`,`id_cliente`,`id_usuario`,`total`,`creado_en`) VALUES ('14','2026-04-30 09:46:33','1','1','3000.00','2026-04-30 09:46:33');
INSERT INTO `ventas` (`id`,`fecha`,`id_cliente`,`id_usuario`,`total`,`creado_en`) VALUES ('15','2026-04-30 09:52:20','1','1','3000.00','2026-04-30 09:52:20');
INSERT INTO `ventas` (`id`,`fecha`,`id_cliente`,`id_usuario`,`total`,`creado_en`) VALUES ('16','2026-04-30 11:38:50','1','1','24000.00','2026-04-30 11:38:50');
INSERT INTO `ventas` (`id`,`fecha`,`id_cliente`,`id_usuario`,`total`,`creado_en`) VALUES ('17','2026-04-30 11:47:46','1','1','3000.00','2026-04-30 11:47:46');
INSERT INTO `ventas` (`id`,`fecha`,`id_cliente`,`id_usuario`,`total`,`creado_en`) VALUES ('18','2026-04-30 11:52:05','1','1','24000.00','2026-04-30 11:52:05');
INSERT INTO `ventas` (`id`,`fecha`,`id_cliente`,`id_usuario`,`total`,`creado_en`) VALUES ('19','2026-05-07 10:03:03','1','1','24000.00','2026-05-07 10:03:03');
INSERT INTO `ventas` (`id`,`fecha`,`id_cliente`,`id_usuario`,`total`,`creado_en`) VALUES ('20','2026-05-07 10:21:29','1','1','105000.00','2026-05-07 10:21:29');
INSERT INTO `ventas` (`id`,`fecha`,`id_cliente`,`id_usuario`,`total`,`creado_en`) VALUES ('21','2026-05-12 10:35:41','1','1','46500.00','2026-05-12 10:35:41');
INSERT INTO `ventas` (`id`,`fecha`,`id_cliente`,`id_usuario`,`total`,`creado_en`) VALUES ('22','2026-05-12 10:48:06','1','1','22500.00','2026-05-12 10:48:06');

SET FOREIGN_KEY_CHECKS=1;
